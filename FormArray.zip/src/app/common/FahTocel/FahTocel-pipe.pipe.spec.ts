/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FahTocelPipePipe } from './FahTocel-pipe.pipe';

describe('Pipe: FahTocelPipee', () => {
  it('create an instance', () => {
    let pipe = new FahTocelPipePipe();
    expect(pipe).toBeTruthy();
  });
});
