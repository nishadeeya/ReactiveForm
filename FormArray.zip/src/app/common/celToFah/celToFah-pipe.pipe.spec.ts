/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CelToFahPipePipe } from './celToFah-pipe.pipe';

describe('Pipe: CelToFahPipee', () => {
  it('create an instance', () => {
    let pipe = new CelToFahPipePipe();
    expect(pipe).toBeTruthy();
  });
});
